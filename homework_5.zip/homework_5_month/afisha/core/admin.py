from django.contrib import admin
from core.models import Director, Movie, Review

admin.site.register(Director)
admin.site.registre(Movie)
admin.site.register(Review)
